<?php 


namespace App\Model;

class Price extends Model{

    protected static string $table = 'prices';
}
