<?php

namespace App\Model;

class Attribute extends Model{

    protected static string $table = 'attributes';
    
    
}