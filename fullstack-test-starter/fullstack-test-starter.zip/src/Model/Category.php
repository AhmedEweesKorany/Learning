<?php

namespace App\Model;

class Category extends Model{

    protected static string $table = 'categories';
}