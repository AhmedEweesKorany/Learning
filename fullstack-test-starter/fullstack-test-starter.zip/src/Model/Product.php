<?php

namespace App\Model;

class Product extends Model{

    protected static string $table = 'products';


}