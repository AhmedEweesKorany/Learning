<?php 

return [
 
        'host' => 'localhost',
        'dbname' => 'ecommerce_test',
        'username' => 'root',
        'password' => '1111'
    
];